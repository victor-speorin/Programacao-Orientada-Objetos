package projeto.dao.impl;

import projeto.dao.DaoCliente;
import projeto.model.Cliente;

public class DaoClienteIMPL extends DaoGenericoIMPL<Cliente> implements DaoCliente{
}
