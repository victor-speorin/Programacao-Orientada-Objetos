package projeto.dao.impl;

import projeto.dao.DaoItemPedido;
import projeto.model.ItemPedido;

public class DaoItemPedidoIMPL extends DaoGenericoIMPL<ItemPedido> implements DaoItemPedido {
}
