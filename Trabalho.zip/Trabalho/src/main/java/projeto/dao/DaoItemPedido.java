package projeto.dao;

import projeto.model.ItemPedido;

public interface DaoItemPedido extends DaoGenerico<ItemPedido>{
}
