package projeto.dao;

import projeto.model.Cliente;

public interface DaoCliente extends DaoGenerico<Cliente>{
}
