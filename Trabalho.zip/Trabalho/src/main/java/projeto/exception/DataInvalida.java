package projeto.exception;

public class DataInvalida extends Exception{
    public DataInvalida(String message) {
        super(message);
    }
}
