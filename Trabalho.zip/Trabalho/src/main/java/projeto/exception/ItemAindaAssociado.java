package projeto.exception;

public class ItemAindaAssociado extends RuntimeException {
    public ItemAindaAssociado(String message) {
        super(message);
    }
}
