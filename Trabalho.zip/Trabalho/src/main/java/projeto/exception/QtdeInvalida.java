package projeto.exception;

public class QtdeInvalida extends RuntimeException {
    public QtdeInvalida(String message) {super(message);}
}
